let jsbCallbackSeed = 1;
const jsbResponseCallbacks = {};
const jsbMethodId = {
  CONSOLE_LOG: 1,
  DONE: 2,
  HTTP_CLIENT_GET: 3,
  HTTP_CLIENT_POST: 4,
  HTTP_CLIENT_HEAD: 5,
  HTTP_CLIENT_DELETE: 6,
  HTTP_CLIENT_PUT: 7,
  HTTP_CLIENT_OPTIONS: 8,
  HTTP_CLIENT_PATCH: 9,
  PERSISTENT_STORE_READ: 10,
  PERSISTENT_STORE_WRITE: 11,
  PERSISTENT_STORE_REMOVE: 12,
  NOTIFICATION_POST: 13,
  UNGZIP: 14,
  GEOIP: 15,
  IPASN: 16,
  IPASO: 17,
  NETWORK: 18,
  ENVIRONMENT: 19,
  SHADOWROCKET: 20,
  HTTP_API: 21,
};

const jsbDataType = {
  RAW: 0,
  BASE64: 1,
  JSON: 2,
};

function jsbCallbackFromNative(callbackId, args) {
  if (!callbackId) return;

  const callback = jsbResponseCallbacks[callbackId];
  if (!callback) return;
  if (args.length === 4) {
    if (args[3]) {
      args[2] = Uint8Array.fromBase64(args[2]);
    }
    callback(args[0], args[1], args[2]);
  }
  else if (args.length === 1) {
    callback(args[0]);
  }

  delete jsbResponseCallbacks[callbackId];
}

const jsbPrompt = (message) => {
  return prompt(JSON.stringify(message));
};

const jsbPostMessage = (message) => {
  window.webkit.messageHandlers.jsbridge.postMessage(message);
};

const console = {
  serialize() {
    let type = jsbDataType.RAW;
    let payload = arguments[0];

    if (arguments.length > 1) {
      payload = Array.from(arguments);
      payload = JSON.stringify(payload);
      type = jsbDataType.JSON;
    }
    else if (payload instanceof Uint8Array) {
      payload = payload.toBase64()
      type = jsbDataType.BASE64;
    } else if (Object.prototype.toString.call(payload) === "[object Object]") {
      payload = JSON.stringify(payload);
      type = jsbDataType.JSON;
    }

    return {
      method: jsbMethodId.CONSOLE_LOG,
      params: payload,
      type,
    };
  },

  log() {
    const message = console.serialize.apply(null, arguments);
    jsbPostMessage(message);
  },

  send(id, args) {
    const message = console.serialize.apply(null, args);
    message.id = id;
    jsbPostMessage(message);
  }
};

const $done = (result, id) => {
  if (result) {
    if (result.response?.body instanceof Uint8Array) {
      result.response.body = result.response.body.toBase64()
      result.response["body-base64"] = 1;
      delete result.body;
      delete result.headers;
    } else if (result.body instanceof Uint8Array) {
      result.body = result.body.toBase64()
      result["body-base64"] = 1;
    }
  }

  jsbPostMessage({
    method: jsbMethodId.DONE,
    params: result,
    id,
  });
}

const sendHttp = (method, options, callback, id) => {
  let params = options;
  let type = jsbDataType.RAW;

  if (typeof options === "object") {

    if (options['body']) {
        if (options.body instanceof Uint8Array) {
            options.body = options.body.toBase64();
            options['binary-mode'] = true;
        }
        else if (options['binary-mode']) {
            options.body = btoa(options.body);
        }
    }

    params = JSON.stringify(options);
    type = jsbDataType.JSON;
  }

  const message = { method, params, type, id };

  if (callback) {
    const callbackId = `js_callback_${jsbCallbackSeed++}_${Date.now()}`;
    jsbResponseCallbacks[callbackId] = callback;
    message.callbackId = callbackId;
  }

  jsbPostMessage(message);
};

const $httpClient = {
  get: (o, cb, id) => sendHttp(jsbMethodId.HTTP_CLIENT_GET, o, cb, id),
  post: (o, cb, id) => sendHttp(jsbMethodId.HTTP_CLIENT_POST, o, cb, id),
  head: (o, cb, id) => sendHttp(jsbMethodId.HTTP_CLIENT_HEAD, o, cb, id),
  delete: (o, cb, id) => sendHttp(jsbMethodId.HTTP_CLIENT_DELETE, o, cb, id),
  put: (o, cb, id) => sendHttp(jsbMethodId.HTTP_CLIENT_PUT, o, cb, id),
  options: (o, cb, id) => sendHttp(jsbMethodId.HTTP_CLIENT_OPTIONS, o, cb, id),
  patch: (o, cb, id) => sendHttp(jsbMethodId.HTTP_CLIENT_PATCH, o, cb, id),
};

const $persistentStore = {
  read(key) {
    return jsbPrompt({ method: jsbMethodId.PERSISTENT_STORE_READ, params: { key } });
  },

  write(value, key) {
    return jsbPrompt({
      method: jsbMethodId.PERSISTENT_STORE_WRITE,
      params: { key, value },
    }) === "true";
  },

  remove(key) {
    return jsbPrompt({ method: jsbMethodId.PERSISTENT_STORE_REMOVE, params: { key } }) === "true";
  },
};

const $notification = {
  post(title, subtitle, body, options) {
    jsbPostMessage({
      method: jsbMethodId.NOTIFICATION_POST,
      params: { title, subtitle, body, options },
    });
  },
};

const $utils = {
  gzip(data) {
    let type = jsbDataType.RAW;

    if (data instanceof Uint8Array) {
      data = data.toBase64();
      type = jsbDataType.BASE64;
    }

    data = jsbPrompt({ method: jsbMethodId.GZIP, params: { data, type } });
    data = Uint8Array.fromBase64(data);

    return data;
  },

  ungzip(data) {
    let type = jsbDataType.RAW;

    if (data instanceof Uint8Array) {
      data = data.toBase64();
      type = jsbDataType.BASE64;
    }

    data = jsbPrompt({ method: jsbMethodId.UNGZIP, params: { data, type } });
    data = Uint8Array.fromBase64(data);

    return data;
  },

  ipasn(ip) {
    return jsbPrompt({ method: jsbMethodId.IPASN, params: { ip } });
  },

  ipaso(ip) {
    return jsbPrompt({ method: jsbMethodId.IPASO, params: { ip } });
  },

  geoip(ip) {
    return jsbPrompt({ method: jsbMethodId.GEOIP, params: { ip } });
  },
};

const $Shadowrocket = new Proxy({
  __ckeys__: new Set(['globalRouting', 'debug', 'tunModeOnly', 'isiOS', 'isMacOS', 'isTVOS', 'version']),
  __cmethods__: new Set(['useServer', 'restart', 'stop', 'toJSON', 'toString']),
}, {
  get(target, prop) {
    if (prop === "__ckeys__" || prop === "__cmethods__") {
      return undefined;
    }

    if (target[prop]) {
      return target[prop];
    }

    if (target.__cmethods__.has(prop)) {
      return (value) => {
        return jsbPrompt({ method: jsbMethodId.SHADOWROCKET, params: { prop, value } });
      };
    }

    if (!target.__ckeys__.has(prop)) {
      return undefined;
    }

    return jsbPrompt({ method: jsbMethodId.SHADOWROCKET, params: { prop } });
  },

  set(target, prop, value) {
    if (!target.__ckeys__.has(prop)) {
      return undefined;
    }

    return jsbPrompt({ method: jsbMethodId.SHADOWROCKET, params: { prop, value } });
  }
});

const $rocket = $Shadowrocket;

const $network = new Proxy({
  __ckeys__: new Set(['interface', 'interface6', 'interfaceV6', 'interfaceV6', 'interfaceV6', 'interfaceV6', 'interfaceV6']),
  __cmethods__: new Set(['toJSON', 'toString']),
}, {
  get(target, prop) {

    if (prop === "__ckeys__" || prop === "__cmethods__") {
      return undefined;
    }

    if (target[prop]) {
      return target[prop];
    }

    if (target.__cmethods__.has(prop)) {
      return () => {
        return jsbPrompt({ method: jsbMethodId.NETWORK, params: { prop } });
      };
    }

    if (!target.__ckeys__.has(prop)) {
      return undefined;
    }

    return jsbPrompt({ method: jsbMethodId.NETWORK, params: { prop } });
  },

  set(target, prop, value) {
    if (!target.__ckeys__.has(prop)) {
      return undefined;
    }

    return jsbPrompt({ method: jsbMethodId.NETWORK, params: { prop, value } });
  }
});


const $environment = new Proxy({
  __ckeys__: new Set(['system', 'build', 'version', 'language']),
  __cmethods__: new Set(['toJSON', 'toString']),
}, {
  get(target, prop) {

    if (prop === "__ckeys__" || prop === "__cmethods__") {
      return undefined;
    }

    if (target[prop]) {
      return target[prop];
    }

    if (target.__cmethods__.has(prop)) {
      return () => {
        return jsbPrompt({ method: jsbMethodId.ENVIRONMENT, params: { prop } });
      };
    }

    if (!target.__ckeys__.has(prop)) {
      return undefined;
    }

    return jsbPrompt({ method: jsbMethodId.ENVIRONMENT, params: { prop } });
  }
});

const $httpAPI = (method, path, args, callback, id) => {
  let type = jsbDataType.RAW;

  if (typeof args === "object") {
    args = JSON.stringify(args);
    type = jsbDataType.JSON;
  }

  const message = { method: jsbMethodId.HTTP_API, params: { method, path, args }, type, id };

  if (callback) {
    const callbackId = `js_callback_${jsbCallbackSeed++}_${Date.now()}`;
    jsbResponseCallbacks[callbackId] = callback;
    message.callbackId = callbackId;
  }

  jsbPostMessage(message);
}

/* disable WebSocket */
(function (window) {
  Object.defineProperty(window, 'WebSocket', {
    configurable: false,
    writable: false,
    value: undefined
  });
})(window);

/* disable document and navigator */
(function (window) {
  window.document = undefined;
  window.navigator = undefined;
})(window);

const $jsbRuntime = ($jsb, $script, $jsBindings) => {
  const $object = $jsb.$object;
  const console = {
    log() {
      $jsb.console.send($object.id, arguments);
    }
  };

  if ($object.binaryBodyMode && $object.body) {
      $object.body = Uint8Array.fromBase64($object.body);
  }

  const jsbPostMessage = () => {
    throw new Error('jsbPostMessage is disabled');
  };

  const jsbPrompt = () => {
    throw new Error('jsbPrompt is disabled');
  };

  const $persistentStore = (function (object) {
    ['read', 'write', 'remove'].forEach((method) => {
      object[method] = function () {
        const args = Array.from(arguments);
        if (args.length === 0 || (args.length === 1 && method === 'write')) {
          args.push($script.file);
        }
        return $jsb.$persistentStore[method].apply(object, args);
      }
    });
    return object;
  })({});

  const $httpAPI = (method, path, args, callback) => {
    $jsb.$httpAPI(method, path, args, callback, $object.id);
  };

  const $httpClient = (function (object) {
    Object.keys($jsb.$httpClient).forEach(method => {
      const original = $jsb.$httpClient[method];
      object[method] = (urlOrOptions, callback) => {
        const options = typeof urlOrOptions === 'string' ? { url: urlOrOptions } : urlOrOptions;
        options.messageId = $object.id;
        return original(options, callback, $object.id);
      };
    });
    return object;
  })({});

  const $done = (result) => {
    const messageId = $object.id;
    if (result) {
      delete result.id;
      Object.assign($object, result);
    }

    if (!$jsb.finished) {
      $jsb.finished = true;
      $jsb.$done($object, messageId);
    } else {
      console.log("$done is only called once");
    }
  };

  const $scriptGlobals = {
    $persistentStore,
    $httpAPI,
    $httpClient,
    $done,
    console,
    jsbPostMessage,
    jsbPrompt,
    $notification,
    $utils,
    $Shadowrocket,
    $rocket,
    $network,
    $environment
  };
  Object.defineProperties($scriptGlobals, $jsBindings);

  const hasScriptGlobal = key => Object.prototype.hasOwnProperty.call($scriptGlobals, key);
  const globalThis = new Proxy(window, {
    has: (target, key) => hasScriptGlobal(key) || key in target,
    get: (target, key) => hasScriptGlobal(key) ? $scriptGlobals[key] : target[key],
    set: (target, key, value) => Reflect.set(hasScriptGlobal(key) ? $scriptGlobals : target, key, value)
  });
  $scriptGlobals.globalThis = globalThis;

  return $scriptGlobals;
};

true;
